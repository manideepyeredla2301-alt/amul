const fs = require('node:fs');
const path = require('node:path');
const { inTransaction, DB_PATH, DATA_DIR } = require('../db');

class AppError extends Error {
  constructor(message, status = 400, code = 'VALIDATION_ERROR') {
    super(message);
    this.status = status;
    this.code = code;
  }
}

const clean = (value) => String(value ?? '').trim();
const whole = (value, label) => {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed <= 0) throw new AppError(`${label} must be a whole number greater than zero.`);
  return parsed;
};
const nonNegativeWhole = (value, label) => {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 0) throw new AppError(`${label} must be a whole number of zero or more.`);
  return parsed;
};
const paise = (value, label = 'Amount') => {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 0) throw new AppError(`${label} must be a valid non-negative amount.`);
  return Math.round(parsed * 100);
};
const dateOnly = (value, label = 'Date') => {
  const result = clean(value) || new Date().toISOString().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(result) || Number.isNaN(Date.parse(`${result}T00:00:00Z`))) {
    throw new AppError(`${label} must use YYYY-MM-DD.`);
  }
  return result;
};
const json = (value) => JSON.stringify(value ?? {});

function addDays(isoDate, days) {
  const date = new Date(`${isoDate}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + Number(days));
  return date.toISOString().slice(0, 10);
}

class ERPService {
  constructor(db) {
    this.db = db;
  }

  audit(action, entityType, entityId, metadata = {}, actor = 'Owner') {
    this.db.prepare(`INSERT INTO audit_log (actor, action, entity_type, entity_id, metadata_json)
      VALUES (?, ?, ?, ?, ?)`).run(actor, action, entityType, entityId ?? null, json(metadata));
  }

  setting(key) {
    return this.db.prepare('SELECT value FROM settings WHERE key = ?').get(key)?.value;
  }

  nextDocument(prefixKey, table, column, date) {
    const prefix = this.setting(prefixKey) || prefixKey.toUpperCase();
    const day = String(date).replaceAll('-', '');
    const pattern = `${prefix}-${day}-%`;
    const count = this.db.prepare(`SELECT COUNT(*) AS count FROM ${table} WHERE ${column} LIKE ?`).get(pattern).count;
    return `${prefix}-${day}-${String(Number(count) + 1).padStart(4, '0')}`;
  }

  getProduct(id) {
    const product = this.db.prepare('SELECT * FROM products WHERE id = ? AND active = 1').get(Number(id));
    if (!product) throw new AppError('The selected product is unavailable.', 404, 'PRODUCT_NOT_FOUND');
    return product;
  }

  getParty(id, expected) {
    const party = this.db.prepare('SELECT * FROM parties WHERE id = ? AND active = 1').get(Number(id));
    if (!party) throw new AppError('The selected customer or supplier is unavailable.', 404, 'PARTY_NOT_FOUND');
    if (expected && party.party_type !== expected && party.party_type !== 'BOTH') {
      throw new AppError(`The selected party is not a ${expected.toLowerCase()}.`);
    }
    return party;
  }

  taxAmounts(taxablePaise, gstBps, party) {
    const tax = Math.round(taxablePaise * Number(gstBps) / 10000);
    const intraState = !party || party.state_code === this.setting('company_state_code');
    return intraState
      ? { cgst: Math.floor(tax / 2), sgst: tax - Math.floor(tax / 2), igst: 0 }
      : { cgst: 0, sgst: 0, igst: tax };
  }

  createProduct(input) {
    const sku = clean(input.sku).toUpperCase();
    const name = clean(input.name);
    if (!sku || !name) throw new AppError('SKU and product name are required.');
    const values = [
      sku, clean(input.barcode) || null, name, clean(input.brand) || null,
      clean(input.category) || 'Ice Cream', clean(input.unit) || 'PCS', clean(input.hsnCode) || null,
      nonNegativeWhole(input.gstBps ?? 1800, 'GST rate'), paise(input.retailPrice ?? 0, 'Retail price'),
      paise(input.wholesalePrice ?? 0, 'Wholesale price'), nonNegativeWhole(input.reorderLevel ?? 0, 'Reorder level'),
    ];
    try {
      const result = this.db.prepare(`INSERT INTO products
        (sku, barcode, name, brand, category, unit, hsn_code, gst_bps, retail_price_paise, wholesale_price_paise, reorder_level)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)` ).run(...values);
      this.audit('CREATE', 'PRODUCT', Number(result.lastInsertRowid), { sku, name });
      return this.getProduct(result.lastInsertRowid);
    } catch (error) {
      if (String(error.message).includes('UNIQUE')) throw new AppError('SKU and barcode must be unique.');
      throw error;
    }
  }

  listProducts() {
    return this.db.prepare(`SELECT p.*, COALESCE(SUM(b.quantity_available), 0) AS stock_qty,
      COALESCE(SUM(b.quantity_available * b.cost_paise), 0) AS stock_value_paise,
      MIN(CASE WHEN b.quantity_available > 0 THEN b.expiry_date END) AS nearest_expiry
      FROM products p LEFT JOIN inventory_batches b ON b.product_id = p.id
      GROUP BY p.id ORDER BY p.active DESC, p.name COLLATE NOCASE`).all();
  }

  createParty(input) {
    const name = clean(input.name);
    const type = clean(input.partyType || 'CUSTOMER').toUpperCase();
    if (!name) throw new AppError('Customer or supplier name is required.');
    if (!['CUSTOMER', 'SUPPLIER', 'BOTH'].includes(type)) throw new AppError('Invalid party type.');
    const count = this.db.prepare('SELECT COUNT(*) AS count FROM parties').get().count;
    const code = clean(input.code).toUpperCase() || `${type.slice(0, 3)}-${String(Number(count) + 1).padStart(4, '0')}`;
    try {
      const result = this.db.prepare(`INSERT INTO parties
        (party_type, code, name, mobile, whatsapp_number, gstin, address, city, state_code, pincode, credit_days, credit_limit_paise)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)` ).run(
        type, code, name, clean(input.mobile) || null, clean(input.whatsappNumber) || null, clean(input.gstin).toUpperCase() || null,
        clean(input.address) || null, clean(input.city) || null, clean(input.stateCode) || this.setting('company_state_code'),
        clean(input.pincode) || null, nonNegativeWhole(input.creditDays ?? this.setting('default_credit_days'), 'Credit days'),
        paise(input.creditLimit ?? 0, 'Credit limit'),
      );
      this.audit('CREATE', 'PARTY', Number(result.lastInsertRowid), { code, name, type });
      return this.getParty(result.lastInsertRowid);
    } catch (error) {
      if (String(error.message).includes('UNIQUE')) throw new AppError('Party code must be unique.');
      throw error;
    }
  }

  listParties(type = null) {
    let sql = `SELECT p.*, COALESCE(SUM(l.debit_paise - l.credit_paise), 0) AS balance_paise
      FROM parties p LEFT JOIN party_ledger_entries l ON l.party_id = p.id`;
    const params = [];
    if (type) {
      sql += ' WHERE (p.party_type = ? OR p.party_type = \'BOTH\')';
      params.push(type);
    }
    sql += ' GROUP BY p.id ORDER BY p.active DESC, p.name COLLATE NOCASE';
    return this.db.prepare(sql).all(...params);
  }

  partyLedger(partyId) {
    const party = this.getParty(partyId);
    const rows = this.db.prepare(`SELECT * FROM party_ledger_entries WHERE party_id = ? ORDER BY entry_date, id`).all(party.id);
    let balance = 0;
    return { party, entries: rows.map((row) => { balance += row.debit_paise - row.credit_paise; return { ...row, balance_paise: balance }; }) };
  }

  validateLines(inputItems, party, priceField) {
    if (!Array.isArray(inputItems) || inputItems.length === 0) throw new AppError('At least one product line is required.');
    return inputItems.map((source) => {
      const product = this.getProduct(source.productId);
      const quantity = whole(source.quantity, `Quantity for ${product.name}`);
      const unitPricePaise = source.unitPrice !== undefined ? paise(source.unitPrice, `Price for ${product.name}`) : product[priceField];
      const taxable = quantity * unitPricePaise;
      const gstBps = source.gstBps === undefined ? product.gst_bps : nonNegativeWhole(source.gstBps, 'GST rate');
      const tax = this.taxAmounts(taxable, gstBps, party);
      return { product, quantity, unitPricePaise, taxable, gstBps, ...tax, total: taxable + tax.cgst + tax.sgst + tax.igst };
    });
  }

  totals(lines) {
    const sum = (key) => lines.reduce((value, line) => value + line[key], 0);
    const subtotal = sum('taxable');
    const cgst = sum('cgst');
    const sgst = sum('sgst');
    const igst = sum('igst');
    return { subtotal, cgst, sgst, igst, total: subtotal + cgst + sgst + igst };
  }

  receivePurchase(input) {
    return inTransaction(this.db, () => {
      const supplier = this.getParty(input.supplierId, 'SUPPLIER');
      const billDate = dateOnly(input.billDate);
      if (!Array.isArray(input.items) || input.items.length === 0) throw new AppError('At least one purchase line is required.');
      const lines = input.items.map((raw) => {
        const product = this.getProduct(raw.productId);
        const quantity = whole(raw.quantity, `Quantity for ${product.name}`);
        const unitCostPaise = paise(raw.unitCost, `Cost for ${product.name}`);
        const taxable = quantity * unitCostPaise;
        const gstBps = raw.gstBps === undefined ? product.gst_bps : nonNegativeWhole(raw.gstBps, 'GST rate');
        const tax = this.taxAmounts(taxable, gstBps, supplier);
        const batchNumber = clean(raw.batchNumber);
        if (!batchNumber) throw new AppError(`Batch number is required for ${product.name}.`);
        const expiryDate = clean(raw.expiryDate) ? dateOnly(raw.expiryDate, 'Expiry date') : null;
        return { product, quantity, unitCostPaise, taxable, gstBps, batchNumber, expiryDate, ...tax, total: taxable + tax.cgst + tax.sgst + tax.igst };
      });
      const totals = this.totals(lines);
      const billNumber = clean(input.billNumber) || this.nextDocument('purchase_prefix', 'purchase_bills', 'bill_number', billDate);
      const header = this.db.prepare(`INSERT INTO purchase_bills
        (bill_number, supplier_id, supplier_bill_number, bill_date, subtotal_paise, cgst_paise, sgst_paise, igst_paise, total_paise, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)` ).run(
        billNumber, supplier.id, clean(input.supplierBillNumber) || null, billDate, totals.subtotal, totals.cgst, totals.sgst, totals.igst, totals.total, clean(input.notes) || null,
      );
      const billId = Number(header.lastInsertRowid);
      const addItem = this.db.prepare(`INSERT INTO purchase_items
        (purchase_bill_id, product_id, batch_number, expiry_date, quantity, unit_cost_paise, gst_bps, taxable_paise, cgst_paise, sgst_paise, igst_paise, line_total_paise)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
      const batchInsert = this.db.prepare(`INSERT INTO inventory_batches
        (product_id, batch_number, expiry_date, cost_paise, quantity_received, quantity_available, source_document)
        VALUES (?, ?, ?, ?, ?, ?, ?)`);
      const batchUpdate = this.db.prepare(`UPDATE inventory_batches SET quantity_received = quantity_received + ?, quantity_available = quantity_available + ? WHERE id = ?`);
      const movement = this.db.prepare(`INSERT INTO stock_movements
        (product_id, batch_id, movement_type, quantity_delta, unit_cost_paise, reference_type, reference_id, reason)
        VALUES (?, ?, 'PURCHASE_RECEIPT', ?, ?, 'PURCHASE_BILL', ?, ?)`);
      for (const line of lines) {
        addItem.run(billId, line.product.id, line.batchNumber, line.expiryDate, line.quantity, line.unitCostPaise, line.gstBps, line.taxable, line.cgst, line.sgst, line.igst, line.total);
        const existing = this.db.prepare(`SELECT id FROM inventory_batches WHERE product_id = ? AND batch_number = ? AND expiry_date IS ?`).get(line.product.id, line.batchNumber, line.expiryDate);
        let batchId;
        if (existing) {
          batchId = existing.id;
          batchUpdate.run(line.quantity, line.quantity, batchId);
        } else {
          batchId = Number(batchInsert.run(line.product.id, line.batchNumber, line.expiryDate, line.unitCostPaise, line.quantity, line.quantity, billNumber).lastInsertRowid);
        }
        movement.run(line.product.id, batchId, line.quantity, line.unitCostPaise, billId, `Stock received through ${billNumber}`);
      }
      this.db.prepare(`INSERT INTO party_ledger_entries
        (party_id, entry_date, entry_type, credit_paise, reference_type, reference_id, narration)
        VALUES (?, ?, 'PURCHASE', ?, 'PURCHASE_BILL', ?, ?)` ).run(supplier.id, billDate, totals.total, billId, `Purchase ${billNumber}`);
      this.audit('POST', 'PURCHASE_BILL', billId, { billNumber, supplier: supplier.name, totalPaise: totals.total });
      return { id: billId, billNumber, ...totals };
    });
  }

  allocateStock(productId, quantity, movementType, referenceType, referenceId, reason) {
    const today = new Date().toISOString().slice(0, 10);
    const batches = this.db.prepare(`SELECT * FROM inventory_batches
      WHERE product_id = ? AND quantity_available > 0 AND (expiry_date IS NULL OR expiry_date >= ?)
      ORDER BY CASE WHEN expiry_date IS NULL THEN 1 ELSE 0 END, expiry_date ASC, id ASC`).all(productId, today);
    let remaining = quantity;
    const allocations = [];
    const movement = this.db.prepare(`INSERT INTO stock_movements
      (product_id, batch_id, movement_type, quantity_delta, unit_cost_paise, reference_type, reference_id, reason)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
    const take = this.db.prepare('UPDATE inventory_batches SET quantity_available = quantity_available - ? WHERE id = ? AND quantity_available >= ?');
    for (const batch of batches) {
      if (remaining === 0) break;
      const picked = Math.min(remaining, batch.quantity_available);
      const result = take.run(picked, batch.id, picked);
      if (result.changes !== 1) throw new AppError('Stock changed while creating the document. Please retry.', 409, 'STOCK_CHANGED');
      movement.run(productId, batch.id, movementType, -picked, batch.cost_paise, referenceType, referenceId, reason);
      allocations.push({ batchId: batch.id, batchNumber: batch.batch_number, quantity: picked });
      remaining -= picked;
    }
    if (remaining > 0) {
      const product = this.getProduct(productId);
      throw new AppError(`Insufficient non-expired stock for ${product.name}. Short by ${remaining}.`, 409, 'INSUFFICIENT_STOCK');
    }
    return allocations;
  }

  createInvoice(input) {
    return inTransaction(this.db, () => {
      const channel = clean(input.channel).toUpperCase();
      if (!['RETAIL', 'DISTRIBUTION'].includes(channel)) throw new AppError('Invoice channel must be RETAIL or DISTRIBUTION.');
      const customer = input.customerId ? this.getParty(input.customerId, 'CUSTOMER') : null;
      if (channel === 'DISTRIBUTION' && !customer) throw new AppError('A customer is required for a distribution invoice.');
      const invoiceDate = dateOnly(input.invoiceDate);
      const deliveryDate = channel === 'DISTRIBUTION' ? dateOnly(input.deliveryDate || invoiceDate, 'Delivery date') : invoiceDate;
      const lines = this.validateLines(input.items, customer, channel === 'RETAIL' ? 'retail_price_paise' : 'wholesale_price_paise');
      const totals = this.totals(lines);
      const payments = Array.isArray(input.payments) ? input.payments : [];
      const paid = payments.reduce((sum, payment) => sum + paise(payment.amount, 'Payment amount'), 0);
      if (paid > totals.total) throw new AppError('Payment cannot exceed invoice total.');
      if (channel === 'RETAIL' && !customer && paid !== totals.total) throw new AppError('Walk-in POS sales must be fully paid. Select a customer to create a credit sale.');
      const invoiceNumber = clean(input.invoiceNumber) || this.nextDocument('invoice_prefix', 'invoices', 'invoice_number', invoiceDate);
      const dueDate = customer && paid < totals.total ? addDays(deliveryDate, customer.credit_days) : null;
      const paymentStatus = paid === 0 ? 'UNPAID' : paid === totals.total ? 'PAID' : 'PART_PAID';
      const header = this.db.prepare(`INSERT INTO invoices
        (invoice_number, channel, customer_id, sales_order_id, invoice_date, delivery_date, due_date, subtotal_paise, cgst_paise, sgst_paise, igst_paise, total_paise, paid_paise, payment_status, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)` ).run(
        invoiceNumber, channel, customer?.id ?? null, input.salesOrderId ? Number(input.salesOrderId) : null, invoiceDate, deliveryDate, dueDate,
        totals.subtotal, totals.cgst, totals.sgst, totals.igst, totals.total, paid, paymentStatus, clean(input.notes) || null,
      );
      const invoiceId = Number(header.lastInsertRowid);
      const item = this.db.prepare(`INSERT INTO invoice_items
        (invoice_id, product_id, quantity, unit_price_paise, gst_bps, taxable_paise, cgst_paise, sgst_paise, igst_paise, line_total_paise)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
      for (const line of lines) {
        item.run(invoiceId, line.product.id, line.quantity, line.unitPricePaise, line.gstBps, line.taxable, line.cgst, line.sgst, line.igst, line.total);
        this.allocateStock(line.product.id, line.quantity, channel === 'RETAIL' ? 'SALE_RETAIL' : 'SALE_DISTRIBUTION', 'INVOICE', invoiceId, `Sold through ${invoiceNumber}`);
      }
      if (customer) {
        this.db.prepare(`INSERT INTO party_ledger_entries
          (party_id, entry_date, entry_type, debit_paise, reference_type, reference_id, narration)
          VALUES (?, ?, 'SALE', ?, 'INVOICE', ?, ?)` ).run(customer.id, invoiceDate, totals.total, invoiceId, `Invoice ${invoiceNumber}`);
      }
      for (const payment of payments) {
        const amount = paise(payment.amount, 'Payment amount');
        if (amount === 0) continue;
        const receiptNumber = this.nextDocument('receipt_prefix', 'payments', 'receipt_number', invoiceDate);
        this.db.prepare(`INSERT INTO payments
          (receipt_number, party_id, invoice_id, payment_date, direction, method, amount_paise, reference_number, notes)
          VALUES (?, ?, ?, ?, 'RECEIPT', ?, ?, ?, ?)` ).run(
          receiptNumber, customer?.id ?? null, invoiceId, invoiceDate, clean(payment.method || 'CASH').toUpperCase(), amount,
          clean(payment.referenceNumber) || null, `Payment against ${invoiceNumber}`,
        );
        if (customer) this.db.prepare(`INSERT INTO party_ledger_entries
          (party_id, entry_date, entry_type, credit_paise, reference_type, reference_id, narration)
          VALUES (?, ?, 'RECEIPT', ?, 'INVOICE', ?, ?)` ).run(customer.id, invoiceDate, amount, invoiceId, `Receipt against ${invoiceNumber}`);
      }
      if (input.salesOrderId) this.db.prepare(`UPDATE sales_orders SET status = 'INVOICED', delivery_date = ? WHERE id = ?`).run(deliveryDate, Number(input.salesOrderId));
      this.audit('POST', 'INVOICE', invoiceId, { invoiceNumber, channel, totalPaise: totals.total, paidPaise: paid });
      return { id: invoiceId, invoiceNumber, channel, dueDate, paymentStatus, ...totals, paidPaise: paid };
    });
  }

  createOrder(input) {
    return inTransaction(this.db, () => {
      const customer = this.getParty(input.customerId, 'CUSTOMER');
      const orderDate = dateOnly(input.orderDate);
      const lines = this.validateLines(input.items, customer, 'wholesale_price_paise');
      const orderNumber = clean(input.orderNumber) || this.nextDocument('order_prefix', 'sales_orders', 'order_number', orderDate);
      const result = this.db.prepare(`INSERT INTO sales_orders (order_number, customer_id, order_date, status, notes)
        VALUES (?, ?, ?, 'CONFIRMED', ?)` ).run(orderNumber, customer.id, orderDate, clean(input.notes) || null);
      const orderId = Number(result.lastInsertRowid);
      const item = this.db.prepare(`INSERT INTO sales_order_items (order_id, product_id, quantity, unit_price_paise, gst_bps) VALUES (?, ?, ?, ?, ?)`);
      for (const line of lines) item.run(orderId, line.product.id, line.quantity, line.unitPricePaise, line.gstBps);
      this.audit('CREATE', 'SALES_ORDER', orderId, { orderNumber, customer: customer.name });
      return { id: orderId, orderNumber };
    });
  }

  deliverOrder(orderId, deliveryDate) {
    const order = this.db.prepare('SELECT * FROM sales_orders WHERE id = ?').get(Number(orderId));
    if (!order) throw new AppError('Order not found.', 404, 'ORDER_NOT_FOUND');
    if (!['CONFIRMED', 'PACKING', 'DELIVERED'].includes(order.status)) throw new AppError('Only confirmed orders can be delivered.');
    const rows = this.db.prepare('SELECT * FROM sales_order_items WHERE order_id = ?').all(order.id);
    return this.createInvoice({
      channel: 'DISTRIBUTION', customerId: order.customer_id, salesOrderId: order.id,
      invoiceDate: deliveryDate || new Date().toISOString().slice(0, 10), deliveryDate: deliveryDate || new Date().toISOString().slice(0, 10),
      items: rows.map((row) => ({ productId: row.product_id, quantity: row.quantity, unitPrice: row.unit_price_paise / 100, gstBps: row.gst_bps })),
      notes: `Generated from order ${order.order_number}`,
    });
  }

  recordReceipt(input) {
    return inTransaction(this.db, () => {
      const party = this.getParty(input.partyId, 'CUSTOMER');
      const amount = paise(input.amount, 'Receipt amount');
      if (amount === 0) throw new AppError('Receipt amount must be greater than zero.');
      const paymentDate = dateOnly(input.paymentDate);
      let invoice = null;
      if (input.invoiceId) {
        invoice = this.db.prepare('SELECT * FROM invoices WHERE id = ? AND status = \'POSTED\'').get(Number(input.invoiceId));
        if (!invoice || invoice.customer_id !== party.id) throw new AppError('The selected invoice does not belong to this customer.');
        if (amount > invoice.total_paise - invoice.paid_paise) throw new AppError('Receipt exceeds the outstanding amount on this invoice.');
      }
      const receiptNumber = clean(input.receiptNumber) || this.nextDocument('receipt_prefix', 'payments', 'receipt_number', paymentDate);
      const result = this.db.prepare(`INSERT INTO payments
        (receipt_number, party_id, invoice_id, payment_date, direction, method, amount_paise, reference_number, notes)
        VALUES (?, ?, ?, ?, 'RECEIPT', ?, ?, ?, ?)` ).run(
        receiptNumber, party.id, invoice?.id ?? null, paymentDate, clean(input.method || 'UPI').toUpperCase(), amount,
        clean(input.referenceNumber) || null, clean(input.notes) || null,
      );
      this.db.prepare(`INSERT INTO party_ledger_entries
        (party_id, entry_date, entry_type, credit_paise, reference_type, reference_id, narration)
        VALUES (?, ?, 'RECEIPT', ?, 'PAYMENT', ?, ?)` ).run(party.id, paymentDate, amount, Number(result.lastInsertRowid), `Receipt ${receiptNumber}`);
      if (invoice) {
        const paid = invoice.paid_paise + amount;
        this.db.prepare('UPDATE invoices SET paid_paise = ?, payment_status = ? WHERE id = ?').run(paid, paid === invoice.total_paise ? 'PAID' : 'PART_PAID', invoice.id);
      }
      this.audit('POST', 'PAYMENT', Number(result.lastInsertRowid), { receiptNumber, party: party.name, amountPaise: amount });
      return { id: Number(result.lastInsertRowid), receiptNumber, amountPaise: amount };
    });
  }

  queueReminder(invoiceId) {
    return inTransaction(this.db, () => {
      const invoice = this.db.prepare(`SELECT i.*, p.name AS customer_name, p.whatsapp_number, p.mobile FROM invoices i
        JOIN parties p ON p.id = i.customer_id WHERE i.id = ? AND i.status = 'POSTED' AND i.payment_status != 'PAID'`).get(Number(invoiceId));
      if (!invoice) throw new AppError('An unpaid customer invoice is required for a reminder.', 404, 'REMINDER_NOT_ELIGIBLE');
      const prior = this.db.prepare(`SELECT id, status FROM reminder_history WHERE invoice_id = ? AND date(created_at) = date('now')
        AND status IN ('QUEUED','SENT') ORDER BY id DESC LIMIT 1`).get(invoice.id);
      if (prior) return { id: prior.id, status: prior.status, skippedDuplicate: true };
      const outstanding = invoice.total_paise - invoice.paid_paise;
      const recipient = invoice.whatsapp_number || invoice.mobile || null;
      const message = `Dear ${invoice.customer_name}, payment of ₹${(outstanding / 100).toFixed(2)} against invoice ${invoice.invoice_number} is due${invoice.due_date ? ` on ${invoice.due_date}` : ''}. Please contact us if already paid. — ${this.setting('company_name')}`;
      const status = recipient ? 'QUEUED' : 'SKIPPED';
      const result = this.db.prepare(`INSERT INTO reminder_history (invoice_id, channel, recipient, status, message)
        VALUES (?, 'WHATSAPP', ?, ?, ?)` ).run(invoice.id, recipient, status, message);
      this.audit('QUEUE', 'PAYMENT_REMINDER', Number(result.lastInsertRowid), { invoiceNumber: invoice.invoice_number, recipient, status });
      return { id: Number(result.lastInsertRowid), status, recipient, message };
    });
  }

  reminderHistory() {
    return this.db.prepare(`SELECT r.*, i.invoice_number, p.name AS customer_name FROM reminder_history r
      JOIN invoices i ON i.id = r.invoice_id JOIN parties p ON p.id = i.customer_id ORDER BY r.created_at DESC, r.id DESC LIMIT 200`).all();
  }

  recordExpense(input) {
    return inTransaction(this.db, () => {
      const expenseDate = dateOnly(input.expenseDate);
      const category = clean(input.category);
      if (!category) throw new AppError('Expense category is required.');
      const amount = paise(input.amount, 'Expense amount');
      if (amount === 0) throw new AppError('Expense amount must be greater than zero.');
      const gstBps = nonNegativeWhole(input.gstBps ?? 0, 'GST rate');
      const gst = Math.round(amount * gstBps / (10000 + gstBps));
      const number = clean(input.expenseNumber) || this.nextDocument('expense_prefix', 'expenses', 'expense_number', expenseDate);
      const result = this.db.prepare(`INSERT INTO expenses
        (expense_number, expense_date, category, payee, method, amount_paise, gst_bps, gst_paise, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)` ).run(number, expenseDate, category, clean(input.payee) || null,
        clean(input.method || 'CASH').toUpperCase(), amount, gstBps, gst, clean(input.notes) || null);
      this.audit('POST', 'EXPENSE', Number(result.lastInsertRowid), { number, category, amountPaise: amount });
      return { id: Number(result.lastInsertRowid), expenseNumber: number, amountPaise: amount };
    });
  }

  adjustStock(input) {
    return inTransaction(this.db, () => {
      const product = this.getProduct(input.productId);
      const quantity = whole(input.quantity, 'Adjustment quantity');
      const type = clean(input.type).toUpperCase();
      const allowed = ['DAMAGE', 'EXPIRY', 'ADJUSTMENT_IN', 'ADJUSTMENT_OUT'];
      if (!allowed.includes(type)) throw new AppError('Invalid stock adjustment type.');
      const reason = clean(input.reason);
      if (!reason) throw new AppError('A reason is required for every stock adjustment.');
      if (type === 'ADJUSTMENT_IN') {
        const batchNumber = clean(input.batchNumber) || `ADJ-${Date.now()}`;
        const cost = paise(input.unitCost ?? 0, 'Unit cost');
        const batch = this.db.prepare(`INSERT INTO inventory_batches
          (product_id, batch_number, expiry_date, cost_paise, quantity_received, quantity_available, source_document)
          VALUES (?, ?, ?, ?, ?, ?, 'STOCK_ADJUSTMENT')`).run(product.id, batchNumber, clean(input.expiryDate) || null, cost, quantity, quantity);
        const adjustmentId = Number(batch.lastInsertRowid);
        this.db.prepare(`INSERT INTO stock_movements
          (product_id, batch_id, movement_type, quantity_delta, unit_cost_paise, reference_type, reference_id, reason)
          VALUES (?, ?, 'ADJUSTMENT_IN', ?, ?, 'STOCK_ADJUSTMENT', ?, ?)` ).run(product.id, adjustmentId, quantity, cost, adjustmentId, reason);
        this.audit('POST', 'STOCK_ADJUSTMENT', adjustmentId, { product: product.name, type, quantity, reason });
        return { id: adjustmentId, quantityDelta: quantity };
      }
      const movementType = type;
      const allocations = this.allocateStock(product.id, quantity, movementType, 'STOCK_ADJUSTMENT', null, reason);
      this.audit('POST', 'STOCK_ADJUSTMENT', null, { product: product.name, type, quantity, reason, allocations });
      return { productId: product.id, quantityDelta: -quantity, allocations };
    });
  }

  createSalesReturn(input) {
    return inTransaction(this.db, () => {
      const invoice = this.db.prepare('SELECT * FROM invoices WHERE id = ? AND status = \'POSTED\'').get(Number(input.invoiceId));
      if (!invoice) throw new AppError('A posted invoice is required for a sales return.');
      const returnDate = dateOnly(input.returnDate);
      if (!Array.isArray(input.items) || input.items.length === 0) throw new AppError('At least one returned product is required.');
      const number = clean(input.returnNumber) || this.nextDocument('return_prefix', 'returns', 'return_number', returnDate);
      const header = this.db.prepare(`INSERT INTO returns (return_number, return_type, party_id, invoice_id, return_date, reason)
        VALUES (?, 'SALES_RETURN', ?, ?, ?, ?)` ).run(number, invoice.customer_id, invoice.id, returnDate, clean(input.reason) || null);
      const returnId = Number(header.lastInsertRowid);
      let total = 0;
      for (const raw of input.items) {
        const invoiceItem = this.db.prepare('SELECT * FROM invoice_items WHERE id = ? AND invoice_id = ?').get(Number(raw.invoiceItemId), invoice.id);
        if (!invoiceItem) throw new AppError('A return line does not belong to the selected invoice.');
        const quantity = whole(raw.quantity, 'Return quantity');
        const previouslyReturned = this.db.prepare(`SELECT COALESCE(SUM(ri.quantity), 0) AS quantity FROM return_items ri
          JOIN returns r ON r.id = ri.return_id WHERE r.return_type = 'SALES_RETURN' AND r.status = 'POSTED' AND ri.source_item_id = ?`).get(invoiceItem.id).quantity;
        if (quantity + previouslyReturned > invoiceItem.quantity) throw new AppError('Returned quantity cannot exceed the remaining quantity on this invoice line.');
        const batchNumber = `RET-${number}-${invoiceItem.product_id}`;
        const lineTotal = Math.round(invoiceItem.line_total_paise * quantity / invoiceItem.quantity);
        const product = this.getProduct(invoiceItem.product_id);
        const averageCost = this.db.prepare('SELECT COALESCE(ROUND(AVG(cost_paise)), 0) AS cost_paise FROM inventory_batches WHERE product_id = ?').get(product.id).cost_paise;
        const batchId = Number(this.db.prepare(`INSERT INTO inventory_batches
          (product_id, batch_number, cost_paise, quantity_received, quantity_available, source_document)
          VALUES (?, ?, ?, ?, ?, ?)` ).run(product.id, batchNumber, averageCost, quantity, quantity, number).lastInsertRowid);
        this.db.prepare(`INSERT INTO return_items (return_id, source_item_id, product_id, batch_id, quantity, unit_price_paise, gst_bps, line_total_paise)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)` ).run(returnId, invoiceItem.id, product.id, batchId, quantity, invoiceItem.unit_price_paise, invoiceItem.gst_bps, lineTotal);
        this.db.prepare(`INSERT INTO stock_movements
          (product_id, batch_id, movement_type, quantity_delta, unit_cost_paise, reference_type, reference_id, reason)
          VALUES (?, ?, 'SALES_RETURN', ?, ?, 'RETURN', ?, ?)` ).run(product.id, batchId, quantity, averageCost, returnId, clean(input.reason) || 'Sales return');
        total += lineTotal;
      }
      this.db.prepare('UPDATE returns SET total_paise = ? WHERE id = ?').run(total, returnId);
      if (invoice.customer_id) this.db.prepare(`INSERT INTO party_ledger_entries
        (party_id, entry_date, entry_type, credit_paise, reference_type, reference_id, narration)
        VALUES (?, ?, 'SALES_RETURN', ?, 'RETURN', ?, ?)` ).run(invoice.customer_id, returnDate, total, returnId, `Sales return ${number}`);
      this.audit('POST', 'RETURN', returnId, { number, type: 'SALES_RETURN', invoiceId: invoice.id, totalPaise: total });
      return { id: returnId, returnNumber: number, totalPaise: total };
    });
  }

  createPurchaseReturn(input) {
    return inTransaction(this.db, () => {
      const bill = this.db.prepare('SELECT * FROM purchase_bills WHERE id = ? AND status = \'POSTED\'').get(Number(input.purchaseBillId));
      if (!bill) throw new AppError('A posted purchase bill is required for a purchase return.');
      const returnDate = dateOnly(input.returnDate);
      if (!Array.isArray(input.items) || input.items.length === 0) throw new AppError('At least one returned product is required.');
      const number = clean(input.returnNumber) || this.nextDocument('return_prefix', 'returns', 'return_number', returnDate);
      const header = this.db.prepare(`INSERT INTO returns (return_number, return_type, party_id, purchase_bill_id, return_date, reason)
        VALUES (?, 'PURCHASE_RETURN', ?, ?, ?, ?)` ).run(number, bill.supplier_id, bill.id, returnDate, clean(input.reason) || null);
      const returnId = Number(header.lastInsertRowid);
      let total = 0;
      for (const raw of input.items) {
        const purchaseItem = this.db.prepare('SELECT * FROM purchase_items WHERE id = ? AND purchase_bill_id = ?').get(Number(raw.purchaseItemId), bill.id);
        if (!purchaseItem) throw new AppError('A return line does not belong to the selected purchase bill.');
        const quantity = whole(raw.quantity, 'Return quantity');
        const previouslyReturned = this.db.prepare(`SELECT COALESCE(SUM(ri.quantity), 0) AS quantity FROM return_items ri
          JOIN returns r ON r.id = ri.return_id WHERE r.return_type = 'PURCHASE_RETURN' AND r.status = 'POSTED' AND ri.source_item_id = ?`).get(purchaseItem.id).quantity;
        if (quantity + previouslyReturned > purchaseItem.quantity) throw new AppError('Returned quantity cannot exceed the original purchase line.');
        const batch = this.db.prepare(`SELECT * FROM inventory_batches WHERE product_id = ? AND batch_number = ? AND expiry_date IS ?`).get(purchaseItem.product_id, purchaseItem.batch_number, purchaseItem.expiry_date);
        if (!batch || batch.quantity_available < quantity) throw new AppError('There is not enough of the original batch available to return.', 409, 'INSUFFICIENT_STOCK');
        const changed = this.db.prepare('UPDATE inventory_batches SET quantity_available = quantity_available - ? WHERE id = ? AND quantity_available >= ?').run(quantity, batch.id, quantity);
        if (changed.changes !== 1) throw new AppError('Stock changed while creating the return. Please retry.', 409, 'STOCK_CHANGED');
        const lineTotal = Math.round(purchaseItem.line_total_paise * quantity / purchaseItem.quantity);
        this.db.prepare(`INSERT INTO return_items (return_id, source_item_id, product_id, batch_id, quantity, unit_price_paise, gst_bps, line_total_paise)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)` ).run(returnId, purchaseItem.id, purchaseItem.product_id, batch.id, quantity, purchaseItem.unit_cost_paise, purchaseItem.gst_bps, lineTotal);
        this.db.prepare(`INSERT INTO stock_movements
          (product_id, batch_id, movement_type, quantity_delta, unit_cost_paise, reference_type, reference_id, reason)
          VALUES (?, ?, 'PURCHASE_RETURN', ?, ?, 'RETURN', ?, ?)` ).run(purchaseItem.product_id, batch.id, -quantity, batch.cost_paise, returnId, clean(input.reason) || 'Purchase return');
        total += lineTotal;
      }
      this.db.prepare('UPDATE returns SET total_paise = ? WHERE id = ?').run(total, returnId);
      this.db.prepare(`INSERT INTO party_ledger_entries
        (party_id, entry_date, entry_type, debit_paise, reference_type, reference_id, narration)
        VALUES (?, ?, 'PURCHASE_RETURN', ?, 'RETURN', ?, ?)` ).run(bill.supplier_id, returnDate, total, returnId, `Purchase return ${number}`);
      this.audit('POST', 'RETURN', returnId, { number, type: 'PURCHASE_RETURN', purchaseBillId: bill.id, totalPaise: total });
      return { id: returnId, returnNumber: number, totalPaise: total };
    });
  }

  inventory() {
    return this.db.prepare(`SELECT p.id AS product_id, p.sku, p.name, p.unit, p.reorder_level,
      b.id AS batch_id, b.batch_number, b.expiry_date, b.cost_paise, b.quantity_received, b.quantity_available,
      b.quantity_available * b.cost_paise AS value_paise,
      CASE WHEN b.expiry_date IS NOT NULL AND b.expiry_date < date('now') THEN 'EXPIRED'
           WHEN b.expiry_date IS NOT NULL AND b.expiry_date <= date('now', '+30 days') THEN 'EXPIRING'
           WHEN b.quantity_available <= p.reorder_level THEN 'LOW' ELSE 'OK' END AS alert
      FROM inventory_batches b JOIN products p ON p.id = b.product_id
      WHERE b.quantity_available > 0 ORDER BY CASE WHEN b.expiry_date IS NULL THEN 1 ELSE 0 END, b.expiry_date, p.name`).all();
  }

  dashboard() {
    const stats = this.db.prepare(`SELECT
      (SELECT COALESCE(SUM(quantity_available * cost_paise), 0) FROM inventory_batches) AS inventory_value_paise,
      (SELECT COALESCE(SUM(total_paise), 0) FROM invoices WHERE status = 'POSTED' AND invoice_date = date('now')) AS sales_today_paise,
      (SELECT COALESCE(SUM(total_paise), 0) FROM invoices WHERE status = 'POSTED' AND strftime('%Y-%m', invoice_date) = strftime('%Y-%m','now')) AS sales_month_paise,
      (SELECT COALESCE(SUM(amount_paise), 0) FROM payments WHERE direction = 'RECEIPT' AND payment_date = date('now')) AS collections_today_paise,
      (SELECT COALESCE(SUM(balance), 0) FROM (SELECT SUM(debit_paise - credit_paise) AS balance FROM party_ledger_entries GROUP BY party_id) WHERE balance > 0) AS receivable_paise,
      (SELECT COALESCE(SUM(quantity_available), 0) FROM inventory_batches) AS stock_units`).get();
    const lowStock = this.db.prepare(`SELECT p.id, p.name, p.sku, p.reorder_level, COALESCE(SUM(b.quantity_available), 0) AS stock_qty
      FROM products p LEFT JOIN inventory_batches b ON b.product_id = p.id WHERE p.active = 1
      GROUP BY p.id HAVING stock_qty <= p.reorder_level ORDER BY stock_qty, p.name LIMIT 8`).all();
    const expiring = this.db.prepare(`SELECT p.name, b.batch_number, b.expiry_date, b.quantity_available FROM inventory_batches b
      JOIN products p ON p.id = b.product_id WHERE b.quantity_available > 0 AND b.expiry_date IS NOT NULL
      AND b.expiry_date <= date('now', '+30 days') ORDER BY b.expiry_date LIMIT 8`).all();
    const overdue = this.db.prepare(`SELECT i.id, i.invoice_number, p.name AS customer_name, i.due_date,
      i.total_paise - i.paid_paise AS outstanding_paise,
      MAX(0, CAST(julianday(date('now')) - julianday(i.due_date) AS INTEGER)) AS days_overdue
      FROM invoices i JOIN parties p ON p.id = i.customer_id
      WHERE i.status = 'POSTED' AND i.payment_status != 'PAID' AND i.due_date < date('now')
      ORDER BY i.due_date LIMIT 10`).all();
    return { stats, lowStock, expiring, overdue };
  }

  invoices() {
    return this.db.prepare(`SELECT i.*, p.name AS customer_name, MAX(0, CAST(julianday(date('now')) - julianday(i.due_date) AS INTEGER)) AS days_overdue
      FROM invoices i LEFT JOIN parties p ON p.id = i.customer_id ORDER BY i.invoice_date DESC, i.id DESC LIMIT 200`).all();
  }

  invoiceDetail(invoiceId) {
    const invoice = this.db.prepare(`SELECT i.*, p.name AS customer_name FROM invoices i LEFT JOIN parties p ON p.id = i.customer_id WHERE i.id = ?`).get(Number(invoiceId));
    if (!invoice) throw new AppError('Invoice not found.', 404, 'INVOICE_NOT_FOUND');
    const items = this.db.prepare(`SELECT ii.*, p.name AS product_name, COALESCE((SELECT SUM(ri.quantity) FROM return_items ri
      JOIN returns r ON r.id = ri.return_id WHERE r.return_type = 'SALES_RETURN' AND r.status = 'POSTED' AND ri.source_item_id = ii.id), 0) AS returned_quantity
      FROM invoice_items ii JOIN products p ON p.id = ii.product_id WHERE ii.invoice_id = ?`).all(invoice.id);
    return { invoice, items };
  }

  orders() {
    return this.db.prepare(`SELECT o.*, p.name AS customer_name, COUNT(oi.id) AS line_count
      FROM sales_orders o JOIN parties p ON p.id = o.customer_id LEFT JOIN sales_order_items oi ON oi.order_id = o.id
      GROUP BY o.id ORDER BY o.order_date DESC, o.id DESC LIMIT 200`).all();
  }

  purchaseBills() {
    return this.db.prepare(`SELECT b.*, p.name AS supplier_name FROM purchase_bills b
      LEFT JOIN parties p ON p.id = b.supplier_id ORDER BY b.bill_date DESC, b.id DESC LIMIT 200`).all();
  }

  purchaseDetail(purchaseBillId) {
    const bill = this.db.prepare(`SELECT b.*, p.name AS supplier_name FROM purchase_bills b LEFT JOIN parties p ON p.id = b.supplier_id WHERE b.id = ?`).get(Number(purchaseBillId));
    if (!bill) throw new AppError('Purchase bill not found.', 404, 'PURCHASE_NOT_FOUND');
    const items = this.db.prepare(`SELECT pi.*, p.name AS product_name, COALESCE((SELECT SUM(ri.quantity) FROM return_items ri
      JOIN returns r ON r.id = ri.return_id WHERE r.return_type = 'PURCHASE_RETURN' AND r.status = 'POSTED' AND ri.source_item_id = pi.id), 0) AS returned_quantity
      FROM purchase_items pi JOIN products p ON p.id = pi.product_id WHERE pi.purchase_bill_id = ?`).all(bill.id);
    return { bill, items };
  }

  returns() {
    return this.db.prepare(`SELECT r.*, p.name AS party_name, i.invoice_number, b.bill_number FROM returns r
      LEFT JOIN parties p ON p.id = r.party_id LEFT JOIN invoices i ON i.id = r.invoice_id LEFT JOIN purchase_bills b ON b.id = r.purchase_bill_id
      ORDER BY r.return_date DESC, r.id DESC LIMIT 200`).all();
  }

  payments() {
    return this.db.prepare(`SELECT pay.*, p.name AS party_name, i.invoice_number FROM payments pay
      LEFT JOIN parties p ON p.id = pay.party_id LEFT JOIN invoices i ON i.id = pay.invoice_id
      ORDER BY pay.payment_date DESC, pay.id DESC LIMIT 200`).all();
  }

  expenses() { return this.db.prepare('SELECT * FROM expenses ORDER BY expense_date DESC, id DESC LIMIT 200').all(); }
  auditLog() { return this.db.prepare('SELECT * FROM audit_log ORDER BY occurred_at DESC, id DESC LIMIT 200').all().map((row) => ({ ...row, metadata: JSON.parse(row.metadata_json) })); }

  reports() {
    const salesByDay = this.db.prepare(`SELECT invoice_date AS date, SUM(total_paise) AS sales_paise, SUM(cgst_paise + sgst_paise + igst_paise) AS output_tax_paise
      FROM invoices WHERE status = 'POSTED' AND invoice_date >= date('now', '-30 days') GROUP BY invoice_date ORDER BY invoice_date`).all();
    const gst = this.db.prepare(`SELECT
      COALESCE((SELECT SUM(cgst_paise + sgst_paise + igst_paise) FROM invoices WHERE status = 'POSTED'),0) AS output_tax_paise,
      COALESCE((SELECT SUM(cgst_paise + sgst_paise + igst_paise) FROM purchase_bills WHERE status = 'POSTED'),0) AS input_tax_paise,
      COALESCE((SELECT SUM(gst_paise) FROM expenses),0) AS expense_input_tax_paise`).get();
    const customerBalances = this.db.prepare(`SELECT p.name, p.mobile, SUM(l.debit_paise - l.credit_paise) AS balance_paise
      FROM parties p JOIN party_ledger_entries l ON l.party_id = p.id
      WHERE p.party_type IN ('CUSTOMER','BOTH') GROUP BY p.id HAVING balance_paise != 0 ORDER BY balance_paise DESC`).all();
    return { salesByDay, gst: { ...gst, estimated_tax_payable_paise: Math.max(0, gst.output_tax_paise - gst.input_tax_paise - gst.expense_input_tax_paise) }, customerBalances };
  }

  createBackup() {
    const directory = path.join(DATA_DIR, 'backups');
    fs.mkdirSync(directory, { recursive: true });
    const stamp = new Date().toISOString().replaceAll(':', '-').replaceAll('.', '-');
    const target = path.join(directory, `frostflow-${stamp}.sqlite`);
    const sqlPath = target.replaceAll("'", "''");
    this.db.exec(`VACUUM INTO '${sqlPath}'`);
    this.audit('CREATE', 'BACKUP', null, { filename: path.basename(target) });
    return { filename: path.basename(target), createdAt: new Date().toISOString() };
  }

  seedDemo() {
    if (this.db.prepare('SELECT COUNT(*) AS count FROM products').get().count > 0) throw new AppError('Demo data can only be loaded into an empty product catalogue.');
    const products = [
      ['KWI-CHOCO-100', 'Kwality Choco Bar 100 ml', 40, 32, 18, 15],
      ['KWI-VANI-500', 'Kwality Vanilla Family Pack 500 ml', 220, 180, 18, 8],
      ['AMU-BUTTER-100', 'Amul Butterscotch Cone 100 ml', 55, 44, 18, 12],
      ['AMU-MANGO-750', 'Amul Mango Tub 750 ml', 310, 260, 18, 5],
    ];
    const supplier = this.createParty({ partyType: 'SUPPLIER', name: 'Demo Frozen Foods Supplier', mobile: '9876543210' });
    const customer = this.createParty({ partyType: 'CUSTOMER', name: 'Demo Corner Store', mobile: '9876501234', whatsappNumber: '919876501234', creditDays: 2 });
    const created = products.map(([sku, name, retail, wholesale, gst, reorder]) => this.createProduct({ sku, name, retailPrice: retail, wholesalePrice: wholesale, gstBps: gst * 100, reorderLevel: reorder, hsnCode: '2105' }));
    this.receivePurchase({ supplierId: supplier.id, billDate: new Date().toISOString().slice(0, 10), supplierBillNumber: 'DEMO-001', items: created.map((p, index) => ({ productId: p.id, quantity: 30 + index * 5, unitCost: Math.round(p.wholesale_price_paise * .78) / 100, batchNumber: `D${index + 1}0926`, expiryDate: '2027-03-31' })) });
    return { products: created.length, customer: customer.name };
  }
}

module.exports = { ERPService, AppError };
