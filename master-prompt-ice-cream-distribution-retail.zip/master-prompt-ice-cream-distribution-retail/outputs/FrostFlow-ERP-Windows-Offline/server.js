const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { openDatabase } = require('./src/db');
const { ERPService, AppError } = require('./src/services/erp-service');

const PORT = Number(process.env.PORT || 4317);
const HOST = '127.0.0.1';
const PUBLIC_DIR = path.join(__dirname, 'public');
const db = openDatabase();
const erp = new ERPService(db);

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
};

function reply(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(body));
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (part) => {
      raw += part;
      if (raw.length > 1_000_000) req.destroy(new AppError('Request body is too large.', 413));
    });
    req.on('end', () => {
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch { reject(new AppError('Request body must be valid JSON.')); }
    });
    req.on('error', reject);
  });
}

function serveFile(res, pathname) {
  const requestPath = pathname === '/' ? '/index.html' : pathname;
  const absolute = path.resolve(PUBLIC_DIR, `.${requestPath}`);
  if (!absolute.startsWith(`${PUBLIC_DIR}${path.sep}`)) return reply(res, 403, { error: 'Forbidden' });
  fs.readFile(absolute, (error, content) => {
    if (error) return reply(res, error.code === 'ENOENT' ? 404 : 500, { error: 'Page not found' });
    res.writeHead(200, { 'Content-Type': MIME[path.extname(absolute)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(content);
  });
}

async function api(req, res, pathname) {
  const body = ['POST', 'PUT', 'PATCH'].includes(req.method) ? await readJson(req) : {};
  if (req.method === 'GET' && pathname === '/api/health') return reply(res, 200, { ok: true, mode: 'offline-first' });
  if (req.method === 'GET' && pathname === '/api/dashboard') return reply(res, 200, erp.dashboard());
  if (req.method === 'GET' && pathname === '/api/products') return reply(res, 200, erp.listProducts());
  if (req.method === 'POST' && pathname === '/api/products') return reply(res, 201, erp.createProduct(body));
  if (req.method === 'GET' && pathname === '/api/customers') return reply(res, 200, erp.listParties('CUSTOMER'));
  if (req.method === 'GET' && pathname === '/api/suppliers') return reply(res, 200, erp.listParties('SUPPLIER'));
  const partyLedger = pathname.match(/^\/api\/parties\/(\d+)\/ledger$/);
  if (req.method === 'GET' && partyLedger) return reply(res, 200, erp.partyLedger(partyLedger[1]));
  if (req.method === 'POST' && pathname === '/api/parties') return reply(res, 201, erp.createParty(body));
  if (req.method === 'GET' && pathname === '/api/inventory') return reply(res, 200, erp.inventory());
  if (req.method === 'GET' && pathname === '/api/invoices') return reply(res, 200, erp.invoices());
  const invoiceDetail = pathname.match(/^\/api\/invoices\/(\d+)$/);
  if (req.method === 'GET' && invoiceDetail) return reply(res, 200, erp.invoiceDetail(invoiceDetail[1]));
  if (req.method === 'GET' && pathname === '/api/orders') return reply(res, 200, erp.orders());
  if (req.method === 'POST' && pathname === '/api/orders') return reply(res, 201, erp.createOrder(body));
  const delivery = pathname.match(/^\/api\/orders\/(\d+)\/deliver$/);
  if (req.method === 'POST' && delivery) return reply(res, 201, erp.deliverOrder(delivery[1], body.deliveryDate));
  if (req.method === 'POST' && pathname === '/api/invoices') return reply(res, 201, erp.createInvoice(body));
  if (req.method === 'GET' && pathname === '/api/purchases') return reply(res, 200, erp.purchaseBills());
  const purchaseDetail = pathname.match(/^\/api\/purchases\/(\d+)$/);
  if (req.method === 'GET' && purchaseDetail) return reply(res, 200, erp.purchaseDetail(purchaseDetail[1]));
  if (req.method === 'POST' && pathname === '/api/purchases') return reply(res, 201, erp.receivePurchase(body));
  if (req.method === 'GET' && pathname === '/api/payments') return reply(res, 200, erp.payments());
  if (req.method === 'POST' && pathname === '/api/payments') return reply(res, 201, erp.recordReceipt(body));
  if (req.method === 'POST' && pathname === '/api/reminders') return reply(res, 201, erp.queueReminder(body.invoiceId));
  if (req.method === 'GET' && pathname === '/api/reminders') return reply(res, 200, erp.reminderHistory());
  if (req.method === 'GET' && pathname === '/api/expenses') return reply(res, 200, erp.expenses());
  if (req.method === 'POST' && pathname === '/api/expenses') return reply(res, 201, erp.recordExpense(body));
  if (req.method === 'POST' && pathname === '/api/inventory/adjustments') return reply(res, 201, erp.adjustStock(body));
  if (req.method === 'POST' && pathname === '/api/returns/sales') return reply(res, 201, erp.createSalesReturn(body));
  if (req.method === 'POST' && pathname === '/api/returns/purchase') return reply(res, 201, erp.createPurchaseReturn(body));
  if (req.method === 'GET' && pathname === '/api/returns') return reply(res, 200, erp.returns());
  if (req.method === 'GET' && pathname === '/api/reports') return reply(res, 200, erp.reports());
  if (req.method === 'GET' && pathname === '/api/audit') return reply(res, 200, erp.auditLog());
  if (req.method === 'POST' && pathname === '/api/backups') return reply(res, 201, erp.createBackup());
  if (req.method === 'POST' && pathname === '/api/demo-data') return reply(res, 201, erp.seedDemo());
  return reply(res, 404, { error: 'API endpoint not found.' });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${HOST}:${PORT}`);
  try {
    if (url.pathname.startsWith('/api/')) await api(req, res, url.pathname);
    else if (req.method === 'GET') serveFile(res, decodeURIComponent(url.pathname));
    else reply(res, 405, { error: 'Method not allowed.' });
  } catch (error) {
    if (!(error instanceof AppError)) console.error(error);
    reply(res, error.status || 500, { error: error.message || 'Unexpected server error.', code: error.code || 'INTERNAL_ERROR' });
  }
});

function start() {
  server.listen(PORT, HOST, () => {
    console.log(`FrostFlow ERP is running locally at http://${HOST}:${PORT}`);
    console.log('Core workflows are offline. Press Ctrl+C to stop the local service.');
  });
}

function shutdown() { server.close(() => { db.close(); process.exit(0); }); }
if (require.main === module) {
  start();
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

module.exports = { server, erp, start };
