const test = require('node:test');
const assert = require('node:assert/strict');
const { server } = require('../server');

test('local HTTP service exposes only local application routes and serves the workspace', async (t) => {
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const address = server.address();
  const base = `http://127.0.0.1:${address.port}`;
  const health = await fetch(`${base}/api/health`);
  assert.equal(health.status, 200);
  assert.deepEqual(await health.json(), { ok: true, mode: 'offline-first' });
  const page = await fetch(`${base}/`);
  assert.equal(page.status, 200);
  assert.match(await page.text(), /FrostFlow ERP/);
  const blocked = await fetch(`${base}/..%2Fserver.js`);
  assert.equal(blocked.status, 403);
});
