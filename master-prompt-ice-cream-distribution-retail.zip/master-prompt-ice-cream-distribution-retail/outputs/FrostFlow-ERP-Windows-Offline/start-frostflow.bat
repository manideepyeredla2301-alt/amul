@echo off
setlocal
cd /d "%~dp0"
start "FrostFlow ERP" http://127.0.0.1:4317
node server.js
endlocal
