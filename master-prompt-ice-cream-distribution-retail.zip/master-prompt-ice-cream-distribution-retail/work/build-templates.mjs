import fs from 'node:fs/promises';
import {createRequire} from 'node:module';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const require=createRequire(import.meta.url);
const {SCHEMAS}=require('../src/services/excel-service.js');
const {readWorkbook}=require('../src/excel-codec.js');
const wb=Workbook.create();
const guide=wb.worksheets.add('Guide');guide.showGridLines=false;
guide.getRange('A2').values=[['FrostFlow Excel import templates']];
guide.getRange('A2').format.font={name:'Arial',size:15,bold:true,color:'#17324D'};
guide.getRange('A4:B4').values=[['Import sheet','How it works']];
const descriptions=Object.values(SCHEMAS).map(s=>[s.sheet,s.notes[0]]);
guide.getRange('A5:B12').values=descriptions;
guide.getRange('A14:B19').values=[
  ['Workflow','Fill the matching sheet. In Excel centre choose the same import type, upload this workbook, review the preview, then post.'],
  ['Prices','Purchase, wholesale and retail prices are INR per stock unit, excluding GST. GST Percent uses 18 for 18%.'],
  ['Stock counts','Quantity is the new absolute count for the named batch. Unlisted batches stay unchanged. Use Purchases for supplier stock receipts.'],
  ['Identifiers','Keep SKU, party codes, phone numbers, barcodes, GSTIN and state codes as text to preserve leading zeros.'],
  ['Dates and formulas','Enter dates as YYYY-MM-DD or Excel dates. Paste Special → Values for calculated cells before uploading.'],
  ['Limits','Up to 5,000 rows per file and 5 MB. Imports use the selected sheet. A validation error prevents the whole import from posting.']
];
guide.getRange('A4:B19').format.font={name:'Arial',size:11,color:'#172F40'};
guide.getRange('A4:B4').format={fill:'#17324D',font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'},rowHeight:28};
guide.getRange('A5:A19').format.columnWidth=22;guide.getRange('B5:B19').format.columnWidth=94;
guide.getRange('B5:B19').format.wrapText=true;guide.getRange('A5:B19').format.rowHeight=44;guide.getRange('A5:B19').format.verticalAlignment='center';
guide.tabColor='#17324D';
const money='"₹" #,##0.00;[Red]("₹" #,##0.00)';
for(const s of Object.values(SCHEMAS)) {
  const sheet=wb.worksheets.add(s.sheet);sheet.showGridLines=false;
  sheet.getRangeByIndexes(0,0,1,s.headers.length).values=[s.headers];
  const area=sheet.getRangeByIndexes(0,0,101,s.headers.length);
  area.format.font={name:'Arial',size:11,color:'#17324D'};area.format.rowHeight=22;
  area.format.columnWidth=19;area.format.verticalAlignment='center';
  const head=sheet.getRangeByIndexes(0,0,1,s.headers.length);
  head.format={fill:'#17324D',font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'},wrapText:true,rowHeight:36,horizontalAlignment:'center'};
  sheet.freezePanes.freezeRows(1);sheet.freezePanes.freezeColumns(1);
  sheet.getRangeByIndexes(1,0,100,s.headers.length).format.fill='#FFF9E9';
  for(let i=0;i<s.headers.length;i++) {
    const name=s.headers[i];const cells=sheet.getRangeByIndexes(1,i,100,1);
    cells.setNumberFormat(/Price|Cost|Amount|Balance|Limit/.test(name)?money:/Quantity|Level|Days/.test(name)?'0':name==='GST Percent'?'0.00':'@');
    if(/Date$/.test(name))cells.setNumberFormat('yyyy-mm-dd');
    if(['Name','Address','Notes','Reason'].includes(name))sheet.getRangeByIndexes(0,i,101,1).format.columnWidth=28;
    if(name==='GST Percent')cells.dataValidation={rule:{type:'whole',operator:'between',formula1:0,formula2:100}};
    if(name==='Direction')cells.dataValidation={rule:{type:'list',values:['RECEIPT','PAYMENT']}};
    if(name==='Channel')cells.dataValidation={rule:{type:'list',values:['RETAIL','DISTRIBUTION']}};
    if(name==='Method'||name==='Payment Method')cells.dataValidation={rule:{type:'list',values:['CASH','UPI','CARD','BANK','OTHER']}};
  }
}
wb.recalculate();
console.log((await wb.inspect({kind:'sheet',include:'id,name',maxChars:1500})).ndjson);
console.log((await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?',options:{useRegex:true,maxResults:10},maxChars:1000})).ndjson);
await fs.mkdir('work/template-previews',{recursive:true});
for(const name of ['Guide',...Object.values(SCHEMAS).map(s=>s.sheet)]){
 const n=name==='Guide'?2:SCHEMAS[Object.keys(SCHEMAS).find(k=>SCHEMAS[k].sheet===name)].headers.length;
 const col=String.fromCharCode(64+n);
 const image=await wb.render({sheetName:name,range:name==='Guide'?'A1:B19':`A1:${col}5`,scale:1,format:'png'});
 await fs.writeFile(`work/template-previews/${name}.png`,new Uint8Array(await image.arrayBuffer()));
}
const output=await SpreadsheetFile.exportXlsx(wb);await output.save('outputs/FrostFlow-Excel-Templates.xlsx');
const bytes=await fs.readFile('outputs/FrostFlow-Excel-Templates.xlsx');
const decoded=await readWorkbook(bytes,'FrostFlow-Excel-Templates.xlsx');
for(const s of Object.values(SCHEMAS)){const actual=decoded.find(x=>x.name===s.sheet);if(JSON.stringify(actual.rows[0])!==JSON.stringify(s.headers))throw new Error(`Template heading mismatch: ${s.sheet}`);}
console.log('Verified nine worksheet template workbook; all import headers preserved.');
