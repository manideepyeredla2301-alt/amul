const net=require('node:net');
const dgram=require('node:dgram');
const results={subnet:'192.168.0.0/24',browserResponses:[],openPorts:[],errors:{}};
function probe(host,port){return new Promise(resolve=>{
 const socket=new net.Socket();let open=false,done=false;
 const finish=(extra={})=>{if(done)return;done=true;if(open)results.openPorts.push({host,port,...extra});socket.destroy();resolve();};
 socket.setTimeout(800,()=>finish({tds:'No pre-login response'}));
 socket.on('error',e=>{if(!['ECONNREFUSED','ETIMEDOUT','EHOSTUNREACH'].includes(e.code))results.errors[e.code]=(results.errors[e.code]||0)+1;finish();});
 socket.on('data',data=>finish({tds:data[0]===4?'TDS server response confirmed':'Unidentified TCP service',responseBytes:data.length}));
 socket.connect(port,host,()=>{open=true;const body=Buffer.from([0,0,11,0,6,1,0,17,0,1,255,0,0,0,0,0,0,2]);const head=Buffer.from([18,1,0,26,0,0,1,0]);socket.write(Buffer.concat([head,body]));});
});}
async function discover(){
 const udp=dgram.createSocket('udp4');
 udp.on('error',e=>{results.errors['UDP_'+e.code]=(results.errors['UDP_'+e.code]||0)+1;});
 udp.on('message',(data,r)=>{const detail=data.subarray(data[0]===5?3:0).toString('utf8');if(!results.browserResponses.some(x=>x.host===r.address&&x.detail===detail))results.browserResponses.push({host:r.address,detail});});
 await new Promise(resolve=>udp.bind(0,'0.0.0.0',resolve));udp.setBroadcast(true);
 udp.send(Buffer.from([2]),1434,'192.168.0.255');
 let next=1;
 await Promise.all(Array.from({length:24},async()=>{while(next<=254){const host='192.168.0.'+next++;udp.send(Buffer.from([2]),1434,host);await probe(host,1433);}}));
 await new Promise(resolve=>setTimeout(resolve,1500));udp.close();
 for(const r of results.browserResponses){for(const m of r.detail.matchAll(/(?:^|;)tcp;(\d+)(?:;|$)/gi)){const port=Number(m[1]);if(port!==1433&&port>0&&port<65536)await probe(r.host,port);}}
 console.log(JSON.stringify(results,null,2));
}
discover().catch(e=>{console.error(e.message);process.exitCode=1;});
