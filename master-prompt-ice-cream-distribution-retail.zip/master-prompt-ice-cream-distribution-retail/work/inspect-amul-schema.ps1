param([string]$Server = '192.168.0.106\SQLEXPRESSAMUL', [string]$Database = 'master', [switch]$Schema)
$ErrorActionPreference = 'Stop'
$sqlConnection = $null
try {
    $connectionOptions = [System.Data.SqlClient.SqlConnectionStringBuilder]::new()
    $connectionOptions['Data Source'] = $Server
    $connectionOptions['Initial Catalog'] = $Database
    $connectionOptions['User ID'] = $env:FROSTFLOW_SQL_USER
    $connectionOptions['Password'] = $env:FROSTFLOW_SQL_PASSWORD
    $connectionOptions['Application Name'] = 'FrostFlow read-only schema inspection'
    $connectionOptions['ApplicationIntent'] = 'ReadOnly'
    $connectionOptions['Connect Timeout'] = 8
    $connectionOptions['Encrypt'] = $true
    $connectionOptions['TrustServerCertificate'] = $false
    $connectionOptions['Persist Security Info'] = $false
    $sqlConnection = [System.Data.SqlClient.SqlConnection]::new($connectionOptions.ConnectionString)
    $sqlConnection.Open()
    $sqlCommand = $sqlConnection.CreateCommand()
    $sqlCommand.CommandTimeout = 10
    $sqlCommand.CommandText = 'SELECT name, state_desc, HAS_DBACCESS(name) AS has_access FROM sys.databases WHERE database_id > 4 ORDER BY name'
    if ($Schema) {
        $sqlCommand.CommandText = @'
SELECT s.name AS schema_name, t.name AS table_name, c.column_id, c.name AS column_name,
ty.name AS data_type, c.max_length, c.precision, c.scale, c.is_nullable,
CASE WHEN EXISTS (SELECT 1 FROM sys.indexes i JOIN sys.index_columns ic ON i.object_id=ic.object_id AND i.index_id=ic.index_id WHERE i.object_id=t.object_id AND i.is_primary_key=1 AND ic.column_id=c.column_id) THEN 1 ELSE 0 END AS primary_key
FROM sys.tables t JOIN sys.schemas s ON t.schema_id=s.schema_id
JOIN sys.columns c ON c.object_id=t.object_id JOIN sys.types ty ON c.user_type_id=ty.user_type_id
WHERE t.is_ms_shipped=0 ORDER BY s.name,t.name,c.column_id
'@
    }
    $reader = $sqlCommand.ExecuteReader()
    $databaseRows = @()
    while ($reader.Read()) {
        $record = [ordered]@{}
        for ($field = 0; $field -lt $reader.FieldCount; $field++) { $record[$reader.GetName($field)] = $reader.GetValue($field) }
        $databaseRows += [pscustomobject]$record
    }
    $reader.Close()
    [pscustomobject]@{connected=$true;server=$Server;database=$Database;records=$databaseRows} | ConvertTo-Json -Depth 4
} catch {
    $baseError = $_.Exception.GetBaseException()
    [pscustomobject]@{connected=$false;server=$Server;error_type=$baseError.GetType().FullName;error=$baseError.Message} | ConvertTo-Json -Depth 3
    exit 1
} finally {
    if ($sqlConnection) { $sqlConnection.Dispose() }
    Remove-Item Env:FROSTFLOW_SQL_PASSWORD -ErrorAction SilentlyContinue
    Remove-Item Env:FROSTFLOW_SQL_USER -ErrorAction SilentlyContinue
}
