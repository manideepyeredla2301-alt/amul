$ErrorActionPreference = 'Stop'
$connection = [System.Data.SqlClient.SqlConnection]::new('Server=tcp:100.105.240.98,1433;Database=0002018303_GVR ENTERPRISES;User ID=amuluser;Password=1234;Encrypt=True;TrustServerCertificate=True;ApplicationIntent=ReadOnly;Connect Timeout=15;Application Name=FrostFlow price report')
try {
  $connection.Open()
  $command = $connection.CreateCommand()
  $command.CommandTimeout = 90
  $command.CommandText = @'
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
WITH Sold AS (
 SELECT d.PrdId,
        MAX(h.SalInvDate) AS LastSoldDate,
        SUM(CAST(COALESCE(d.BaseQty,0) AS decimal(19,4))) AS UnitsSold,
        COUNT(DISTINCT h.SalId) AS InvoiceCount
 FROM dbo.SalesInvoice h
 JOIN dbo.SalesInvoiceProduct d ON d.SalId=h.SalId
 WHERE h.SalInvDate >= DATEADD(month,-2,CONVERT(date,GETDATE()))
 GROUP BY d.PrdId
), Latest AS (
 SELECT d.PrdId,d.PrdUnitMRP,d.PrdUnitSelRate,
        ROW_NUMBER() OVER(PARTITION BY d.PrdId ORDER BY h.SalInvDate DESC,h.SalId DESC,d.SlNo DESC) AS rn
 FROM dbo.SalesInvoice h
 JOIN dbo.SalesInvoiceProduct d ON d.SalId=h.SalId
 WHERE h.SalInvDate >= DATEADD(month,-2,CONVERT(date,GETDATE()))
)
SELECT p.PrdId,p.PrdDCode AS SKU,p.PrdName,p.EANCode AS Barcode,p.PrdStatus,
       s.LastSoldDate,s.UnitsSold,s.InvoiceCount,
       CAST(COALESCE(l.PrdUnitMRP,0) AS decimal(19,4)) AS MRP,
       CAST(COALESCE(l.PrdUnitSelRate,0) AS decimal(19,4)) AS RetailerPrice
FROM Sold s
JOIN dbo.Product p ON p.PrdId=s.PrdId
JOIN Latest l ON l.PrdId=s.PrdId AND l.rn=1
WHERE p.PrdStatus=1
ORDER BY p.PrdName;
'@
  $reader = $command.ExecuteReader()
  $rows = @()
  while ($reader.Read()) {
    $row = [ordered]@{}
    for ($i=0; $i -lt $reader.FieldCount; $i++) {
      $value = $reader.GetValue($i)
      $row[$reader.GetName($i)] = if ($value -is [DBNull]) { $null } else { $value }
    }
    $rows += [pscustomobject]$row
  }
  $reader.Close()
  $rows | ConvertTo-Json -Depth 4
} finally {
  if ($connection) { $connection.Dispose() }
}
