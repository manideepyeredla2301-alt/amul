import fs from 'node:fs/promises';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';

const root=process.cwd();
const source=JSON.parse(await fs.readFile(`${root}/tmp/active-products.json`,'utf8'));
const icePattern=/^(IC)|\bice\s*cream\b|\bfrozen\s+dessert\b|\bkulfi\b|\btricone\b/i;
const dairyPattern=/\b(butter|cheese|paneer|milk|dahi|curd|lassi|chaas|buttermilk|ghee|cream|yogurt|yoghurt|shrikhand|khoa|khoya|whey|amulya|milkshake|peda)\b/i;
const classify=r=>icePattern.test(String(r.SKU))||icePattern.test(r.PrdName)?'Ice Cream':dairyPattern.test(r.PrdName)?'Dairy':null;
const groups={
  'Ice Cream':source.filter(r=>classify(r)==='Ice Cream'),
  'Dairy':source.filter(r=>classify(r)==='Dairy'),
};
const wb=Workbook.create();
const font='Arial';
for(const [name,rows] of Object.entries(groups)){
  const sh=wb.worksheets.add(name);
  sh.showGridLines=false;sh.tabColor=name==='Ice Cream'?'#1478B8':'#22A676';
  sh.getRange('A2:I2').merge();sh.getRange('A2').values=[[`${name} products actively sold`]];
  sh.getRange('A2:I2').format={font:{name:font,size:15,bold:true,color:'#152B3E'},rowHeight:25};
  sh.getRange('A3:I3').merge();sh.getRange('A3').values=[['Sales period: 19 Jul 2026 to 19 Sep 2026. Prices are from each product’s latest sale in this period.']];
  sh.getRange('A3:I3').format={font:{name:font,size:10,italic:true,color:'#607487'},rowHeight:20};
  const headers=['SKU','Barcode','Product','MRP (₹)','Retailer price (₹)','Retailer % off MRP','Units sold','Invoices','Last sold'];
  sh.getRange('A5:I5').values=[headers];
  sh.getRange('A5:I5').format={fill:'#16435F',font:{name:font,size:10,bold:true,color:'#FFFFFF'},horizontalAlignment:'center',verticalAlignment:'center',rowHeight:28,borders:{preset:'inside',style:'thin',color:'#FFFFFF'}};
  if(rows.length){
    const values=rows.map(r=>{const [y,m,d]=r.LastSoldDate.slice(0,10).split('-').map(Number);return [String(r.SKU||''),null,r.PrdName,Number(Number(r.MRP).toFixed(2)),Number(Number(r.RetailerPrice).toFixed(2)),null,Number(r.UnitsSold),Number(r.InvoiceCount),new Date(Date.UTC(y,m-1,d,12))];});
    sh.getRangeByIndexes(5,0,values.length,9).values=values;
    sh.getRange(`B6:B${rows.length+5}`).formulas=rows.map(r=>[`="${String(r.Barcode||'').replace(/"/g,'""')}"`]);
    sh.getRange('F6').formulas=[['=IF(D6>0,(D6-E6)/D6,"")']];
    sh.getRange(`F6:F${rows.length+5}`).fillDown();
    sh.getRange(`A6:I${rows.length+5}`).format={font:{name:font,size:10,color:'#152B3E'},verticalAlignment:'center',borders:{insideHorizontal:{style:'thin',color:'#E4EBF1'}}};
    sh.getRange(`A5:I${rows.length+5}`).format.autofitRows();
    sh.tables.add(`A5:I${rows.length+5}`,true,`${name.replace(/\s/g,'')}Products`).style='TableStyleMedium2';
    sh.getRange(`B6:B${rows.length+5}`).format.numberFormat='@';
    sh.getRange(`D6:E${rows.length+5}`).format.numberFormat='₹#,##0.00';
    sh.getRange(`F6:F${rows.length+5}`).format.numberFormat='0.00%';
    sh.getRange(`G6:G${rows.length+5}`).format.numberFormat='#,##0.00';
    sh.getRange(`H6:H${rows.length+5}`).format.numberFormat='#,##0';
    sh.getRange(`I6:I${rows.length+5}`).format.numberFormat='dd-mmm-yyyy';
  }
  sh.getRange('A:I').format.font={name:font,size:10};
  const widths=[15,18,48,13,17,19,13,10,15];
  widths.forEach((width,i)=>sh.getRangeByIndexes(0,i,Math.max(rows.length+5,6),1).format.columnWidth=width);
  sh.getRange(`C6:C${Math.max(6,rows.length+5)}`).format.wrapText=true;
  sh.freezePanes.freezeRows(5);sh.freezePanes.freezeColumns(3);
}
wb.recalculate();
for(const name of Object.keys(groups)){
  const rows=groups[name];
  const check=await wb.inspect({kind:'table',sheetId:name,range:`A2:I${Math.min(rows.length+5,12)}`,include:'values,formulas',tableMaxRows:12,tableMaxCols:9,maxChars:5000});
  console.log(check.ndjson);
}
const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:100},summary:'final formula error scan'});
console.log(errors.ndjson);
await fs.mkdir(`${root}/outputs/active-product-prices`,{recursive:true});
for(const name of Object.keys(groups)){
  const preview=await wb.render({sheetName:name,range:`A1:I${Math.min(groups[name].length+5,24)}`,scale:1,format:'png'});
  await fs.writeFile(`${root}/tmp/${name.replace(/\s/g,'-').toLowerCase()}-preview.png`,new Uint8Array(await preview.arrayBuffer()));
}
const output=await SpreadsheetFile.exportXlsx(wb);
await output.save(`${root}/outputs/active-product-prices/Active-products-last-2-months.xlsx`);
console.log(JSON.stringify({counts:Object.fromEntries(Object.entries(groups).map(([k,v])=>[k,v.length])),excluded:source.length-groups['Ice Cream'].length-groups.Dairy.length}));
