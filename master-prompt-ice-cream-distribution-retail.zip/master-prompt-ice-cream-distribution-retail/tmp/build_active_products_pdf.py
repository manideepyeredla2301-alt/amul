import json,re,os
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4,landscape
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT,TA_RIGHT
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate,Table,TableStyle,Paragraph,PageBreak

root=os.path.dirname(os.path.dirname(__file__))
rows=json.load(open(os.path.join(root,'tmp','active-products.json'),encoding='utf-8'))
ice=re.compile(r'^(IC)|\bice\s*cream\b|\bfrozen\s+dessert\b|\bkulfi\b|\btricone\b',re.I)
dairy=re.compile(r'\b(butter|cheese|paneer|milk|dahi|curd|lassi|chaas|buttermilk|ghee|cream|yogurt|yoghurt|shrikhand|khoa|khoya|whey|amulya|milkshake|peda)\b',re.I)
groups={'Ice Cream':[r for r in rows if ice.search(str(r.get('SKU',''))) or ice.search(r['PrdName'])], 'Dairy':[r for r in rows if not (ice.search(str(r.get('SKU',''))) or ice.search(r['PrdName'])) and dairy.search(r['PrdName'])]}
out=os.path.join(root,'outputs','active-product-prices','Active-products-last-2-months.pdf');os.makedirs(os.path.dirname(out),exist_ok=True)
styles=getSampleStyleSheet();title=ParagraphStyle('title',parent=styles['Title'],fontName='Helvetica-Bold',fontSize=16,textColor=colors.HexColor('#152B3E'),spaceAfter=3);note=ParagraphStyle('note',parent=styles['Normal'],fontName='Helvetica-Oblique',fontSize=8,textColor=colors.HexColor('#607487'),spaceAfter=8);cell=ParagraphStyle('cell',parent=styles['Normal'],fontName='Helvetica',fontSize=7.2,leading=8.4);cellr=ParagraphStyle('cellr',parent=cell,alignment=TA_RIGHT)
def money(v): return f'₹{float(v):,.2f}'
story=[]
def section(name,data):
 story.append(Paragraph(f'{name} products actively sold',title));story.append(Paragraph("Sales period: 20 Jul 2026 to 19 Sep 2026. Prices are from each product's latest sale in this period. Retailer % off MRP = (MRP - retailer price) / MRP.",note))
 header=['SKU','Barcode','Product','MRP','Retailer price','Retailer % off MRP','Units sold','Invoices','Last sold']; hstyle=ParagraphStyle('h',parent=cell,fontName='Helvetica-Bold',textColor=colors.white)
 matrix=[[Paragraph(x,hstyle if i not in [3,4,5,6,7] else ParagraphStyle('hr',parent=hstyle,alignment=TA_RIGHT)) for i,x in enumerate(header)]]
 for r in data:
  mrp=float(r.get('MRP') or 0);price=float(r.get('RetailerPrice') or 0);pct=(mrp-price)/mrp if mrp else 0
  vals=[r.get('SKU',''),r.get('Barcode',''),r['PrdName'],money(mrp),money(price),f'{pct:.2%}',f"{float(r.get('UnitsSold') or 0):,.2f}",f"{int(r.get('InvoiceCount') or 0):,}",str(r.get('LastSoldDate',''))[:10]]
  matrix.append([Paragraph(str(v),cellr if i in [3,4,5,6,7] else cell) for i,v in enumerate(vals)])
 widths=[27*mm,31*mm,78*mm,22*mm,28*mm,34*mm,23*mm,19*mm,25*mm]
 t=Table(matrix,colWidths=widths,repeatRows=1)
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#16435F')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4),('TOPPADDING',(0,0),(-1,0),6),('BOTTOMPADDING',(0,0),(-1,0),6),('TOPPADDING',(0,1),(-1,-1),3),('BOTTOMPADDING',(0,1),(-1,-1),3),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#E8F3F8')]),('LINEBELOW',(0,0),(-1,0),0.6,colors.white),('LINEBELOW',(0,1),(-1,-1),0.25,colors.HexColor('#D5E2E9'))]))
 story.append(t)
for i,(name,data) in enumerate(groups.items()):
 section(name,data)
 if i==0: story.append(PageBreak())
SimpleDocTemplate(out,pagesize=landscape(A4),rightMargin=9*mm,leftMargin=9*mm,topMargin=9*mm,bottomMargin=10*mm,title='Active Amul products - last two months').build(story)
print(json.dumps({k:len(v) for k,v in groups.items()}))
