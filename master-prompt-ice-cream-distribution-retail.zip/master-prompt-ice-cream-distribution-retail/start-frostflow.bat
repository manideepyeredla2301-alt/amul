@echo off
setlocal
cd /d "%~dp0"
title FrostFlow ERP

if exist "%~dp0runtime\node.exe" (
  "%~dp0runtime\node.exe" "%~dp0scripts\launch.js"
) else (
  where node.exe >nul 2>nul
  if errorlevel 1 (
    echo.
    echo Node.js was not found.
    echo Extract the full portable FrostFlow package, including runtime\node.exe.
    echo Alternatively, install Node.js 24 LTS or newer, then run this file again.
    echo.
    pause
    exit /b 1
  )
  node.exe "%~dp0scripts\launch.js"
)

if errorlevel 1 (
  echo.
  echo FrostFlow could not run. The error is shown above.
  pause
  exit /b 1
)
endlocal
