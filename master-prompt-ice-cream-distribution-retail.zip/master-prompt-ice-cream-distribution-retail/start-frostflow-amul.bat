@echo off
setlocal
where pwsh.exe >nul 2>nul
if errorlevel 1 (
  "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe" -NoProfile -File "%~dp0scripts\start-amul.ps1"
) else (
  pwsh.exe -NoProfile -File "%~dp0scripts\start-amul.ps1"
)
pause
